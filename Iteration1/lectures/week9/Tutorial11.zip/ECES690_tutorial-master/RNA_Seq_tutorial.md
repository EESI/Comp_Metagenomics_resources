# RNA-Seq Analyses of gut microbiota.
Nick Minnich and Steve Pastor - ECES 690 Tutorial

## RNA-Seq
Simply put, RNA-Seq profiles transcriptomes/metatranscriptomes and makes use of next-generation sequencing technologies.

## Differential Expression
For our purposes, we would like to measure any differences in the levels of transcripts between two groups from the paper we discussed in our presentation. We will analyze the differential expression changes between stool samples that have been placed in RNAlater as compared to those that have simply been frozen.

## Our Dataset
Relating the metatranscriptome and metagenome of the human gut
http://www.ncbi.nlm.nih.gov/pmc/articles/PMC4050606/

SRA Files: <br>
http://trace.ncbi.nlm.nih.gov/Traces/sra/?study=SRP019038

Once downloaded, convert to fastq:
```
FILES=(SRR769395.sra SRR769401.sra SRR769404.sra SRR769405.sra SRR769407.sra SRR769413.sra SRR769416.sra SRR769418.sra SRR769419.sra SRR769429.sra  SRR769431.sra SRR769433.sra SRR769435.sra SRR769436.sra SRR769439.sra SRR769441.sra)

for i in "${FILES[@]}"; do fastq-dump --split-3 $i; done
```
Use the `--split-3` flag since we have paired-end data and the flag automatically produces two files for us.
Directly from the help for `--split-3`:
First, biological reads satisfying dumping conditions are placed in files *_1.fastq and *_2.fastq If only one biological read is present it is placed in *.fastq Biological reads and above are ignored.


## *de novo* Alignment
#### IDBA_UD:
http://i.cs.hku.hk/~alse/hkubrg/projects/idba_ud/
```
# Example:
idba_ud --num_threads 32 -r *.fastq -o $PWD/out
```

Run with 32 threads, and use the `-r` flag due to the reads being <= 128 BP.

#### FQ -> FA:
Before we can run IDBA_MT, we have to convert the fastq files to fasta files: <br>
```
# Example:
fq2fa —paired SRR769395_1.fastq SRR769395_1.fasta
```

#### IDBA_MT(P):
http://i.cs.hku.hk/~alse/hkubrg/projects/idba_mt/index.html
```
# Example:
$IDBA_MT_DIR/idba-mt -t SRR769395_1.fasta -f SRR769395_2.fasta -r 101 -c $IDBA_UD_OUT/contig.fa -O $IDBA_MT_OUT/395_mt_out.fa > 395_mt_out.fa
```
Here, we use the paired-end reads in tandem. <br>
`-t`: forward <br>
`-f`: reverse <br>
`-r`: read length <br>
`-c`: contig file from IDBA_UD. 

#### Important Note:
Installing IDBA_MT(P) can be problematic for some, but not all. For those that come across errors when attempting to run the `make` command, you may have to insert: <br>
`#include <stdint.h>` into the existing libheader.h file.

## Bowtie2 - Index
```
# Example
bowtie2-build mt_merged_contigs.fa index_output
```

## Bowtie2 - Alignment
```
# Example:
bowtie2 -x index_output -1 SRR769395_1.fastq -2 SRR769395_2.fastq -S 395_aligned.sam
```
`-1`: forward <br>
`-2`: reverse <br>
`-S`: Output is in the SAM format.

## Samtools - File Conversions

```
# Example:
samtools view -bS 395_aligned.sam -o 395_aligned.bam
```
`-b`: Creates the output in the BAM format. <br>
`-S`: Ignored for compatibility with previous samtools versions. Previously this option was required if input was in SAM format, but now the correct format is automatically detected by examining the first few characters of input (http://www.htslib.org/doc/samtools-1.1.html). <br>
`-o`: Output is in the Bam format.

```
# Example:
samtools sort 395_aligned.bam 395_sorted.bam
```
Sort the BAM file so it can be used later with our built reference (via Cufflinks).

## Cufflinks - DE quantification
From this point until edgeR and DESeq2, many of the descriptions come from: <br> http://cole-trapnell-lab.github.io/cufflinks/cufflinks/index.html <br>

Also: <br> 
Trapnell C, Roberts A, Goff L, Pertea G, Kim D, Kelley DR, Pimentel H,
Salzberg SL, Rinn JL, Pachter L. Differential gene and transcript expression
analysis of RNA-seq experiments with TopHat and Cufflinks. Nat Protoc. 2012 Mar
1;7(3):562-78. <br>

```
# Example:
cufflinks -o cufflinks_out -p $NSLOTS 395_sorted.bam
```
`-o`: Output dir of choice. <br>
`-p`: Number of threads used during analysis. $NSLOTS is an integer value (e.g.: 32) - make sure to set this as will help with the process immensely. <br>

##### Output files:
Three files: <br>
*Transcript-level expression: isoforms.fpkm_tracking*

This file contains the estimated isoform-level expression values in the generic FPKM Tracking Format. <br>

*Transcriptome assembly: transcripts.gtf*

This GTF file contains Cufflinks’ assembled isoforms and will be merged with all other Cufflinks .gtf files for use in Cuffdiff. <br>

*Gene-level expression: genes.fpkm_tracking*

This file contains the estimated gene-level expression values in the generic FPKM Tracking Format. <br>
Within this file, we care about the FPKM column. Further, be sure to look at the FPKM Status column: be sure it has the value "OK"for each sample.

## Cuffmerge - Combine Cufflinks Assemblies
[GTF/GFF](http://www.sanger.ac.uk/resources/software/gff/) is a format for describing genes and other features associated with DNA, RNA and Protein sequences.

```
# Example:
cuffmerge -p 32 -o merged assembly_list.txt
```
`-o`: Directory where merged assembly will be written. <br>
`-p`: Use this many threads to merge assemblies. <br>
*assembly_list.txt: Rather than provide the gtf files, we can place a columnar list of the .gtf filenames obtained from Cufflinks. Each row is a .gtf filename.

## Cuffdiff - DE quantification
Please refer to: http://cole-trapnell-lab.github.io/cufflinks/cuffdiff/ <br>
Supply merged GTF from Cuffmerge.
```
# Example:
cuffdiff merged.gtf -L G1,G2 395_sorted.bam,396_sorted.bam 400_sorted.bam,401_sorted.bam -o /cuffdiff/
```
`-L`: Labels for samples. <br>
`G1,G2`: Specifies groups. <br>
`-o` Output directory of choice. <br>

There are several output files. Again, we are primarily concerned with the genes.fpkm_tracking file, and this file along with several other will be input into the R package, cummeRbund.

## cummeRbund:
Please refer to: http://compbio.mit.edu/cummeRbund/ <br>

A [cummerbund](http://en.wikipedia.org/wiki/Cummerbund) is a broad waist sash. cummeRbund, however, is a program that takes output files from cuffdiff run and creates an SQLite database of the results describing appropriate relationships betweeen genes, transcripts, transcription start sites, and CDS regions. It has very helpful visualizations.

#### Results:
```
library(cummeRbund)
setwd("$CUFFDIFF/DATA/DIR")

# Load and look at the stats of the data from cuffdiff:
cuff <- readCufflinks()
cuff

# Plot the data: SCV plot:
fpkmSCVPlot(genes(cuff))
```
Figure 1. Plot of Square Coefficient Variation (SCV). G1 is the frozen samples and G2 is the RNAlater samples. <br>

![alt text](https://cloud.githubusercontent.com/assets/6876998/7916736/b95f68d2-0853-11e5-96ef-91489959d6c2.png)

The squared coefficient of variation is a normalized measure of cross-replicate variability that can be useful for evaluating the quality your RNA-seq data. Differences in CV2 can result in lower numbers of differentially expressed genes due to a higher degree of variability between replicate fpkm estimates.
Overdispersion is a common issue in cufflinks/cuffdiff (greater variability in a dataset than expected
given a model). <br>
```
# Draw a density plot of genes in the two samples.
csDensity(genes(cuff))
```
Figure 2. Density plot of the genes in the two samples.

![alt text](https://cloud.githubusercontent.com/assets/6876998/7916741/c0829c74-0853-11e5-8863-6f413f285e78.png)

csDensity plot: To assess the distributions of FPKM scores across samples. 
(log(fpkm) = ~1.25 has highest density in both scenarios). <br>

```
# Draw a scatter plot. This command also requires X and Y arguments, 'G1' and 'G2', respectively.
csScatter(genes(cuff), 'G1', 'G2',smooth=T)
```
Figure 3. Pairwise comparison of the fpkm counts via a scatter plot. Frozen (G1): x axis and RNAlater (G2): y axis.

![alt text](https://cloud.githubusercontent.com/assets/6876998/7916749/c9315536-0853-11e5-9915-187b1d7d4976.png)

Dashed line: a line with slope 1 and intercept 0. If the two groups we are comparing have a correlation coefficient of 1, dots cluster along the line. Blue line: regression along the actual points that we have. With this, we can see how our actual correlation deviates from 1.

```
# Draw a Volcano matrix plot.
csVolcanoMatrix(isoforms(cuff), 'G1', 'G2')
```

Figure 4. Volcano plot of log fold change in expression vs -log(pval, 95% conf) for a pair of (set of) samples (G1,G2). In other words, it is a plot of fold change vs. significance for a pairwise comparison of genes across two different sets of samples.

![alt text](https://cloud.githubusercontent.com/assets/6876998/7920322/658e2004-086c-11e5-8ef4-498f0b8bb6d0.png)

There are no significant difference between the frozen and RNAlater samples. If there were, there would be red dots. Those would be the significantly different genes.
to pinpoint their functionality. <br>

```
# How many significantly up or down regulated genes are there at a threshold of 0.05?
sig <- getSig(cuff, alpha=0.05, level='genes')
length(sig)
# We have 0!
```
At a 95% confidence level, we have 0 significantly up or down regulate genes. <br>
<br>

If we had significantly different genes:
```
# Get gene data from cuff database:
# sigGenes <- getGenes(cuff,sig)

# Examine the gene set:
# sigGenes

# Draw scatter plot with this subset of genes:
# csScatter(sigGenes, 'G1', 'G2')

# Draw a heatmap of these genes:
# csHeatmap(sigGenes, cluster='both')
```


## Samtools - Read Counts
For the R packages, we require raw read counts and not FPKM like in Cufflinks/Cuffdiff.
```
# Example:
samtools view -q 2 -Sb 395_sorted.bam > 395_filtered 
samtools sort 395_filtered 395_filtered_sorted
samtools index 395_filtered_sorted.bam
samtools idxstats 395_filtered_sorted.bam > 395_stats.txt
```
The resulting text file will contain the gene IDs as the first column and the counts as the third column. <br>
Merge the files into one.

## edgeR
The R package, edgeR, provides statistical routines for assessing differential expression in RNASeq
experiments.
<br>

User manual:
http://www.bioconductor.org/packages/release/bioc/vignettes/edgeR/inst/doc/edgeRUsersGuide.pdf

A quick start guide (from the manual above):
```
# 2 types of analysis:
# 1. Classic edgeR, done for experiments with single factor, 2 groups.
x <- read.delim("fileofcounts.txt",row.names="Symbol")
group <- factor(c(1,1,2,2))
y <- DGEList(counts=x,group=group)
y <- calcNormFactors(y)
y <- estimateCommonDisp(y)
y <- estimateTagwiseDisp(y)
et <- exactTest(y)
topTags(et)

# 2. GLM edgeR, used for when Classic does not hold:
design <- model.matrix(~group)
y <- estimateGLMCommonDisp(y,design)
y <- estimateGLMTrendedDisp(y,design)
y <- estimateGLMTagwiseDisp(y,design)
fit <- glmFit(y,design)
lrt <- glmLRT(fit,coef=2)
topTags(lrt)

# Notice how it is almost the same, except a design matrix is created in GLM.
```

####Our dataset:

```
## To install and load:
source("http://bioconductor.org/biocLite.R")
biocLite("edgeR")

library(edgeR)
#setwd("YOUR/CHOICE")


## Importing and file exploration.-----------
counts <- read.delim("read_counts.txt", header = TRUE, row.names=1)
counts_raw <- read.delim("read_counts.txt", header = FALSE, skip = 1)
counts_raw <- counts_raw[ , 2:(ncol(counts_raw))]


dim(counttable_raw)
# [1] 2711297       6
# So, we have 2,711,297 rows (labeled by contig ID).


# Libary sizes; sum of counts down each column.
colSums(counttable_raw)      
#    V2     V3     V4     V5     V6     V7 
# 91968 144192 286874 183571 181662  84146 

# Number of genes with low counts (10 as an example).
table(rowSums(counts_raw))[2:11]
#    1    2    3    4    5    6    7    8    9   10 
# 2777 1495  958  690  569  441  381  303  259  263 


# Grouping factor, by treatment. "F" denotes Frozen and "R" denotes RNAlater samples. Let's use 3 from each:
group <- c(rep("F", 3) , rep("R", 3))


## Begin the edgeR analysis.-----------
# edgeR stores data in this list object.
y <- DGEList(counts=counts_raw,group=group)

#The 2 components of DGEList are a count matrix and data.frame containing info about the libraries (samples).


# Get some info on your samples:
# names(y)
# y$samples # contains a summary of your samples


# We can filter out the lowly expressed, keeping those w/ at least 50 count in 3 or more samples:
keep <- rowSums(cpm(y)>50) >= 3  # cpm: count per million
y_high <- y[keep,,keep.lib.sizes=FALSE]

# [1] 1552  6 - Large drop from > 2.7 million.


# Re-compute the library size:
y_high$samples$lib.size <- colSums(y_high$counts)


## Normalizing.-----------
# Compute effective library sizes using TMM normalization:
y <- calcNormFactors(y)
y$samples$lib.size * y$samples$norm.factors


#Check out the applied normalization factors to each group.
y_high$samples
y_high

# [1]  32324  32498  30684  51190  30793  26794  28090  50545  29575  31912  29182  46527  33301
# [14]  49793  27429  29444  84038 202970 113517  88126  77201 142129  48708 169585  44115  71711
# [27] 207505 100238  76163 112565 151855 156770


## Data exploration.-----------
#An MDS plot shows distances, in terms of biological coefficient of variation (BCV), BETWEEN samples.
plotMDS(y_high)

# Could save it:
# pdf("MDS_plot_1_ex1.pdf", width = 7, height = 7) # in inches
# plotMDS(y_high, main = "MDS Plot for Count Data", labels = colnames(y_high$counts))
# dev.off() # this tells [R] to close and stop writing to the pdf.
```
Figure 1. Multidimensional Scaling (MDS Plot). This plot shows the difference in log fold changes of the samples. There does not appear to be a big difference between the 2 samples, as 2 frozen samples (V2 and V3) group on the first dimension with an RNAlater sample (V7). Also, 1 frozen sample (V4) groups with 2 RNAlater samples (V5 and V6). Thus, there does not seem to be an obvious log fold change difference between the two groups of samples. <br> 

![alt text](https://cloud.githubusercontent.com/assets/6876998/7917160/3ebe9730-0856-11e5-924d-652ef130f307.png)



```
# Dimension 1 separates the freezing samples (left) from the RNAlater samples (right). 
# Dimension 2 doesn't separate the frozen samples as much as the RNAlater samples.
# We may find a lot of DE genes.


## Estimating Dispersion.-----------
# Dispersion estimates the overall BCV of the dataset, averaged over all genes.
y_high <- estimateCommonDisp(y_high, verbose=TRUE)
# Disp = 1.13924 , BCV = 1.0674 
# The BCV (square root of the common dispersion) here is >1, so skewed to the right.
# The standard deviation exceeded the mean value.


# Now estimate gene-specific dispersions:
y_high <- estimateTagwiseDisp(y_high)
#names(y_high)
summary(y_high$tagwise.dispersion)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.2303  0.5078  0.9397  1.0730  1.4350  4.3410 


plotBCV(y_high)
```

Figure 2. Biological Coefficient of Variation Plot. This plot shows the biological coefficient of variation (BCV) against gene abundance (in log2 counts per million). The BCV is the square root of the negative binomial dispersion. This plot displays the common and tagwise BCV estimates. Some genes may show more biological variability than others. A measure of this, the BCV, is inferred from how much the variance of the counts exceeds the variance that would arise from Poisson counts. Here, the lower the cpm, the lower the BCV.

![alt text](https://cloud.githubusercontent.com/assets/6876998/7917213/94d836c6-0856-11e5-8464-f7821054b056.png)

```
## Differential expression.-----------
# Compute exact genewise tests for differential expression between Frozen and RNAlater groups:
et <- exactTest(y_high)
#et <- exactTest(y_high, pair=c("F","R"))
top <- topTags(et)
top

# Comparison of groups:  R-F 
#             logFC    logCPM      PValue FDR
# 1741307  2.544412  6.428553 0.005761881   1
# 58571    2.727071  6.600954 0.006409392   1
# 1739030 -4.095069  8.016355 0.007918308   1
# 67296    3.107939  6.087629 0.010526541   1
# 2502994  2.605282  6.754736 0.018735583   1
# 2672915  2.129678  5.891709 0.020972143   1
# 67363    2.490503  6.785794 0.021104663   1
# 74835   -4.847747 10.019143 0.024760045   1
# 1741985  1.982226  6.268120 0.026136785   1
# 1741434  2.079849  6.208547 0.027367437   1


#Check the individual cpm values for the top genes:
cpm(y)[rownames(top), ]

#             V2    V3     V4     V5     V6    V7     V8     V9    V10    V11   V12    V13   V14
# 1524840  35887 46742  54458  19223  37379 37881  53755  19013  39154  48634 39031  32712 50479
# 2429898 263028 85791 145970 101153 284351 46913 130970 109487 113439 149034 45817 356695 83721
# 2429890  27070 74590  13720  35359  26500 52996  35742  34365  62484  12190 52465  11413 69968


# The total number of DE genes at 5% FDR is given by:
summary(de <- decideTestsDGE(et))

   [,1]
-1    0
0  1552
1     0

# Here the entries for -1, 0 and 1 are for down-regulated, non-differentially expressed and
# up-regulated respectively. 0 up, 1552 non-DE, 0 down.


# Plot the log-fold-changes, highlighting the DE genes:
detags <- rownames(y_high)[as.logical(de)]
plotSmear(et, de.tags=detags)
abline(h=c(-1, 1), col="blue")
```

Figure 3. Plot of the log-fold changes. The blue lines indicate 1-fold changes. We did not have any significantly up or down-regulated genes. This is apparent from the y-axis, as the largest values is a 4 fold change. We would likely see upwards of 10 or more fold-changes if we have significantly differentially expressed genes.
![alt text](https://cloud.githubusercontent.com/assets/6876998/7917362/c7b29c66-0857-11e5-8659-a8b8fb105ad3.png)


```
# Heatmap:
cpm_log <- cpm(y_high, log = TRUE)
heatmap(cor(cpm_log))
```

Figure 4. Heatmap. This figure simply illustrates the comparison of log(cpm) of the 6 samples. We again see that there are 2 RNAlater samples (V5 and V6) grouped with 1 frozen (V4) and 2 frozens (V2 and V3) with RNAlater samples (V7). The intensity of the similarities is denoted by a darker red value. <br>
![alt text](https://cloud.githubusercontent.com/assets/6876998/7917426/60492bc0-0858-11e5-8d2d-58151958cdd4.png)

## DESeq2
Package:
http://www.bioconductor.org/packages/release/bioc/html/DESeq2.html
<br>
Manual:
http://www.bioconductor.org/packages/release/bioc/vignettes/DESeq2/inst/doc/DESeq2.pdf
<br>
Code:
```
## To install and load:
source("http://bioconductor.org/biocLite.R")
biocLite("DESeq2")

library(DESeq2)
#setwd("YOUR/CHOICE")


## Importation and file exploration.
countdata <- read.table("finally.txt", header=TRUE, row.names=1)


# Convert to a matrix:
countdata <- as.matrix(countdata)
head(countdata)

#              frozen_1 frozen_2 frozen_3 rna_1 rna_2 rna_3
# contig-100_0        0        1        0     1     1     0
# contig-100_1        0        0        0     0     0     0
# contig-100_2        0        0        0     0     0     0
# contig-100_3        0        0        0     0     0     0
# contig-100_4        0        0        0     0     0     0
# contig-100_5        0        0        0     0     0     0

# Assign conditions - "F": Frozen, "R": RNAlaterfirst.
(condition <- factor(c(rep("F", 3), rep("R", 3))))
```
<br>
Step 2:
```
## Data.frame creation and instantiation.

# Create columnar data.frame:
(coldata <- data.frame(row.names=colnames(countdata), condition))

# Instantiate the DESeqDataSet:
dds <- DESeqDataSetFromMatrix(countData=countdata, colData=coldata, design=~condition)
dds

# class: DESeqDataSet 
# dim: 2711297 6 
# exptData(0):
# assays(1): counts
# rownames(2711297): contig-100_0 contig-100_1 ... contig-80_56625 *
# rowData metadata column names(0):
# colnames(6): frozen_1 frozen_2 ... rna_2 rna_3
# colData names(1): condition
```
<br>
Step 3:
```
## DESeq Pipeline.
# DESeq pipeline, WARNING: this may take a while:
dds <- DESeq(dds)

# estimating size factor
# estimating dispersions
# gene-wise dispersion estimates
# mean-dispersion relationship
# final dispersion estimates
# fitting model and testing

# Let's look at the results from the pipeline:
res <- results(dds)
res <- res [order(res$padj),]
head(res)

# log2 fold change (MAP): condition R vs F 
# Wald test p-value: condition R vs F 
# DataFrame with 6 rows and 6 columns
#                  baseMean log2FoldChange     lfcSE      stat       pvalue      padj
#                 <numeric>      <numeric> <numeric> <numeric>    <numeric> <numeric>
# contig-40_37631 110.64090      -3.331245 0.8850966 -3.763708 0.0001674124 0.0904027
# contig-20_11311  21.60942       5.619674 1.6835755  3.337940 0.0008440201 0.2278854
# contig-40_34778  27.73041      -3.598402 1.1553177 -3.114642 0.0018416798 0.3315024
# contig-20_3620   29.73394      -2.672294 1.0237344 -2.610339 0.0090452497 0.8140725
# contig-40_36834 107.23122      -2.783883 1.0371144 -2.684259 0.0072690815 0.8140725
# contig-80_28669  50.16725      -3.275408 1.2525694 -2.614952 0.0089240101 0.8140725
```
<br>
Step 4:
```
## Visualize the results.
# Plot the dispersions (placed in PWD):
png("qc-dispersions.png", 1000, 1000, pointsize=20)
plotDispEsts(dds, main="Dispersion plot")
dev.off()

# We can save the table, and also print out some information on what the columns mean.
mcols(res, use.names=TRUE)

# DataFrame with 6 rows and 2 columns
#                        type                               description
#                 <character>                               <character>
# baseMean       intermediate mean of normalized counts for all samples
# log2FoldChange      results  log2 fold change (MAP): condition R vs F
# lfcSE               results          standard error: condition R vs F
# stat                results          Wald statistic: condition R vs F
# pvalue              results       Wald test p-value: condition R vs F
# padj                results                      BH adjusted p-values
```
Figure 1. Dispersion Plot. Here, we are illustrating what was mentioned in the slides about the dispersion shrinking. This plot shows the plot of dispersion estimates over the average expression strength for the dataset with 6 samples. Black dots are placed via MLE, a curve is placed (red), then they are shrunken (blue).

![alt text](https://cloud.githubusercontent.com/assets/6876998/7917853/4afa4a4e-085b-11e5-8970-c9b038ee4069.png)
<br>
<br>
Step 5.
```
## Clustering.
# Transform (shrinking) the raw counts so that we can do clustering.
# Regularized log transformation for use in clustering/heatmaps and more.
# WARNING, may take a long time:
rld <- rlogTransformation(dds)

# Take a peak at the rld data:
head(assay(rld)) 

#               frozen_1  frozen_2  frozen_3     rna_1     rna_2     rna_3
# contig-100_0 -1.621461 -1.274928 -1.625707 -1.127829 -1.116824 -1.641151
# contig-100_1  0.000000  0.000000  0.000000  0.000000  0.000000  0.000000
# contig-100_2  0.000000  0.000000  0.000000  0.000000  0.000000  0.000000
# contig-100_3  0.000000  0.000000  0.000000  0.000000  0.000000  0.000000
# contig-100_4  0.000000  0.000000  0.000000  0.000000  0.000000  0.000000
# contig-100_5  0.000000  0.000000  0.000000  0.000000  0.000000  0.000000

# Make a histogram:
hist(assay(rld))
```
Figure 2. Histogram of the log transformed counts. The rlogTransformation function performs a summarized experiment of sorts, showing the distribution of the log transformed raw counts. The assay function is used to extract the matrix of normalized values. Since we have a very sparse matrix of counts (raw or in this case, transformed) there is a huge representation of 0 values. <br>
![alt text](https://cloud.githubusercontent.com/assets/6876998/7918655/080fc974-0861-11e5-9a60-3f0035e647e7.png)
<br>
Step 6.
```
## Use RColorBrewer:
library(RColorBrewer)
(mycols <- brewer.pal(8, "Dark2")[1:length(unique(condition))])

# Sample distance heatmap
sampleDists <- as.matrix(dist(t(assay(rld))))
library(gplots)

#In PWD:
png("qc-heatmap-samples.png", w=1000, h=1000, pointsize=20)



heatmap.2(as.matrix(sampleDists), key=F, trace="none",
          col=colorpanel(100, "black", "white"),
          ColSideColors=mycols[condition], RowSideColors=mycols[condition],
          margin=c(10, 10), main="Sample Distance Matrix")
dev.off()
```
Figure 3. Heatmap. Here, we have the heatmap for the samples. Similar to edgeR, we have one of the RNAlater samples grouping with 2 of the frozens and a similar scenario with 1 frozen and 2 RNAlater samples. Since we do not have any significantly different DE genes, it is not surprising that this result occurs. <br>
![alt text](https://cloud.githubusercontent.com/assets/6876998/7918742/980abe3a-0861-11e5-918d-dfa9ffc38f36.png)
<br>
Step 7.
```
## Principal components analysis.
# Do with built-in DESeq2 function:
DESeq2::plotPCA(rld, intgroup="condition")
```
Figure 4. PCA. Here, we have a principal component analysis figure showing the clustering of the two groups of samples. There is no apparent pattern of clustering, showing the lack of difference between the 2 groups. <br>

![alt text](https://cloud.githubusercontent.com/assets/6876998/7918856/70d335d0-0862-11e5-89a9-7f220c7c8ac4.png)
<br>
Step 8.
```
# MA plot:
DESeq2::plotMA(dds, ylim=c(-1,1))
```
Figure 5. MA plot. If there were DE genes, they would be marked in red. The triangles are data removed from analysis. We can see the small log fold change (y axis) across the mean expression (x axis), due to the lack of sig diff DE genes. The red line denotes zero log fold change.
![alt text](https://cloud.githubusercontent.com/assets/6876998/7918978/26aa168a-0863-11e5-8d4b-100bbfc9b87b.png)
<br>
```
# If had significantly DE genes, would make a volcano plot, similar to cummeRbund, showing the DE genes.
```

## FragGeneScan
While we did not have any sig diff DE genes, if we did, we would use Fraggenescan to find genes in the contigs that we have on hand. The reason for Fraggenescan use is because a contig may have several genes. <br>
We need to find (fragmented) genes in short reads, so we will use [FragGeneScan.](http://omics.informatics.indiana.edu/FragGeneScan/)
<br>
<br>
```
# Example call:
./run_FragGeneScan.pl -genome=./example/ -out=./example/fgs_output.txt -complete=0 -train=illumina_5
```
-genome: the genome, here we have the sequencing reads.<br>
-out: output dir<br>
-complete=0: not a complete genome, so 0 (otherwise, 1)
-train: Illumina with 0.5% error rate. Could also use 1% error rate.
<br>
<br>


## BLAST
We can employ the Basic Local Alignment Search Tool (BLAST) to determine the functions of our DE genes of interest. Please see: http://blast.ncbi.nlm.nih.gov/Blast.cgi for explanations to the search type of interest.<br>

Since we have cDNA seqeunces and are interested in the function of the genes (thus, the proteins), we can use BLASTX, which searches a protein database using a translated nucleotide query.
<br>
<br>
Using the results from Fraggenescan and BLASTX we may be able to find the function(s) of the genes that have been significantly DE when comparing different samples exposed to different conditions.

## Future
We will incorporate more samples in the frozen vs RNAlater. Huttenhower, et al found a few genes that were DE in RNAlater, so we may find some when we increase the sample size. Further, we would like to extend this tutorial to comparing all 3 scenarios, and using the GLM method in edgeR.



