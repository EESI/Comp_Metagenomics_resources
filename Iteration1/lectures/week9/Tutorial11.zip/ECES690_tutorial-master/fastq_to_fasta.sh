#!/bin/bash
#$ -S /bin/bash
#$ -cwd
#$ -M sp975@drexel.edu
# Note: Steve - change group from rosenGrp before running this script!
#$ -P nsftuesPrj
#$ -l h_rt=48:00:00
#$ -l h_vmem=20G
#$ -l mem_free=2G
#$ -q all.q@@amdhosts

# Typically loaded modules:
. /etc/profile.d/modules.sh
module load shared
module load proteus
module load sge/univa
module load gcc/4.8.1

# Change the directory to where your fastq files are located.

sra_ids=(
SRR769395_1.fastq
SRR769395_2.fastq
SRR769401_1.fastq
SRR769401_2.fastq
SRR769404_1.fastq
SRR769404_2.fastq
SRR769405_1.fastq
SRR769405_2.fastq
SRR769407_1.fastq
SRR769407_2.fastq
SRR769413_1.fastq
SRR769413_2.fastq
SRR769416_1.fastq
SRR769416_2.fastq
SRR769418_1.fastq
SRR769418_2.fastq
SRR769419_1.fastq
SRR769419_2.fastq
SRR769429_1.fastq
SRR769429_2.fastq
SRR769431_1.fastq
SRR769431_2.fastq
SRR769433_1.fastq
SRR769433_2.fastq
SRR769435_1.fastq
SRR769435_2.fastq
SRR769436_1.fastq
SRR769436_2.fastq
SRR769439_1.fastq
SRR769439_2.fastq
SRR769441_1.fastq
SRR769441_2.fastq
)
for id in "${sra_ids[@]}"; do fq2fa --paired --filter $id $id.fa; done
