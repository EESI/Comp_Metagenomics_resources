#!/bin/bash
#$ -S /bin/bash
#$ -cwd
#$ -M sp975@drexel.edu
# Note: Steve - change group from rosenGrp before running this script!
#$ -P nsftuesPrj
#$ -l h_rt=48:00:00
#$ -l h_vmem=50G
#$ -l mem_free=5G
#$ -q all.q@@amdhosts

PATH=/mnt/HA/groups/nsftuesGrp/.local/bin:$PATH

# Typically loaded modules:
. /etc/profile.d/modules.sh
module load shared
module load proteus
module load sge/univa
module load gcc/4.8.1


###################################################
# 2. de novo Assembly.
###################################################

idba_ud --num_threads 32 -r *.fastq -o ~/metagenomics_tutorial/fastq_files/idba_output/
