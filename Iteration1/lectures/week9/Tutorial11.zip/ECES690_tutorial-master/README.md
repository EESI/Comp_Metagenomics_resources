# ECES690_tutorial
Metagenomics tutorial for class - RNA-Seq Analyses.
