#Classic edgeR flow, for use with single factor experiments:

#setwd("/Users/stevenpastor/downloads")
z <- read.delim("final_test.txt",header = TRUE)
x <- read.delim("final_test.txt", header = FALSE, skip = 1)
x <- x[ , 2:(ncol(x))]
dim(x)  #Tags.
colSums(x)      #Libary sizes.
table(rowSums(x))[2:11] # Number of genes with low counts (10 as an example).

#Grouping factor for my groups.
group <- c(rep("F", 16) , rep("R", 16))

#edgeR stores data in this list object.
#The DGEList object contains a count matrix and a data.frame containing information about the libraries.
y <- DGEList(counts=x,group=group)
names(y)

y$samples # contains a summary of your samples

#Filter out lowly expressed:
keep <- rowSums(cpm(y)>20) >= 16
y_high <- y[keep,,keep.lib.sizes=FALSE]

#Compare these dimensions to the original, dim(x):
dim(y_high)

#Re-compute the library size:
y_high$samples$lib.size <- colSums(y_high$counts)


## Normalizing:
#Compute effective library sizes using TMM normalization:
y_high <- calcNormFactors(y_high)
y_high$samples$lib.size * y_high$samples$norm.factors


#Check out the applied normalization factors to each group.
y_high$samples
y_high


## Data exploration:
#An MDS plot shows distances, in terms of BCV, BETWEEN samples.
plotMDS(y_high)
#pdf("MDS_plot.pdf", width = 7, height = 7)
#plotMDS(y_high, main = "MDS Plot for Count Data", labels = colnames(y_high$counts))
#dev.off() # Stop writing to pdf.

#Dimension 1 clearly separates the freezing samples (left) from the RNAlater samples (right). 
#Dimension 2 doesn't separate the frozen samples as much as the RNAlater samples.

## Estimating Dispersion:
#The dispersion estimates overall BCV of the dataset; averaged over all genes:
y_high <- estimateCommonDisp(y_high, verbose=TRUE)
names(y_high)
#The BCV (square root of the common dispersion) here is >1, so skewed to the right?
#The standard deviation exceeded the mean value.

# The estimate:
# y_high$common.dispersion

# Now estimate gene-specific dispersions:
y_high <- estimateTagwiseDisp(y_high)
#names(y_high)
summary(y_high$tagwise.dispersion)

plotBCV(y_high)


meanVarPlot <- plotMeanVar( y_high , show.raw.vars=TRUE ,
                            show.tagwise.vars=TRUE ,
                            show.binned.common.disp.vars=FALSE ,
                            show.ave.raw.vars=FALSE ,
                            #dispersion.method = "qcml" , 
                            NBline = TRUE ,
                            nbins = 100 ,
                            pch = 16 ,
                            xlab ="Mean Expression (Log10 Scale)" ,
                            ylab = "Variance (Log10 Scale)" ,
                            main = "Mean-Variance Plot" )

meanVarPlot


## Differential expression:
#Compute exact genewise tests for differential expression between Frozen and RNAlater groups:
et <- exactTest(y_high)
#et <- exactTest(y_high, pair=c("F","R"))
top <- topTags(et)
top


#Check the individual cpm values for the top genes:
cpm(y_high)[rownames(top), ]

#The total number of DE genes at 5% FDR is given by:
summary(de <- decideTestsDGE(et))
#Here the entries for -1, 0 and 1 are for down-regulated, non-differentially expressed and
#up-regulated tags respectively.


#Plot the log-fold-changes, highlighting the DE genes:
detags <- rownames(y_high)[as.logical(de)]
plotSmear(et, de.tags=detags)
abline(h=c(-1, 1), col="blue")
#The blue lines indicate fold changes.


#Heatmap:
cpm_log <- cpm(y_high, log = TRUE)
heatmap(cor(cpm_log))   #Need to label.
