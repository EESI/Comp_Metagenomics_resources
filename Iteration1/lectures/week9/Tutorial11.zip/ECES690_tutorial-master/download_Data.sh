#!/bin/bash
#$ -S /bin/bash
#$ -cwd
#$ -M sp975@drexel.edu
# Note: Steve - change group from rosenGrp before running this script!
#$ -P nsftuesPrj
#$ -l h_rt=48:00:00
#$ -l h_vmem=8G
#$ -l mem_free=2G
#$ -q all.q@@amdhosts

PATH=/mnt/HA/groups/nsftuesGrp/.local/bin:$PATH

# Typically loaded modules:
. /etc/profile.d/modules.sh
module load shared
module load proteus
module load sge/univa
module load gcc/4.8.1


###################################################
# 1. File Gathering.
###################################################

# Choose and make paths:
mkdir $HOME/metagenomics_tutorial/sra_data
sraData="$HOME/metagenomics_tutorial/sra_data"

# After downloading .sra files, convert into fastq (paired-end reads):
sra_ids=(
SRR769395
SRR769405
SRR769416
SRR769429
SRR769435
SRR769441
SRR769401
SRR769407
SRR769418
SRR769431
SRR769436
SRR769404
SRR769413
SRR769419
SRR769433
SRR769439
)

# Note the --split-3 flag below, as these are paired-end reads.
for id in "${sra_ids[@]}"; do fastq-dump --split-3 $id; done
