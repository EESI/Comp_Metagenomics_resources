# cummeRbund

# Load package and data:
library(cummeRbund)
setwd("/Users/stevenpastor/downloads/cuffdiff_final/")

# Load the cuffdiff data and look at the stats:
cuff <- readCufflinks()
cuff

# Plot the data:
#The squared coefficient of variation is a normalized measure of cross-replicate 
# variability that can be useful for evaluating the quality your RNA-seq data. 
# Run an SCV plot.
fpkmSCVPlot(genes(cuff))

# Draw a density plot of genes in the two samples.
csDensity(genes(cuff))

# Draw a scatter plot. This command also requires X and Y arguments, 'G1' and 'G2', respectively.
csScatter(genes(cuff), 'G1', 'G2',smooth=T)

# Draw a Volcano matrix plot.
csVolcanoMatrix(isoforms(cuff), 'G1', 'G2')

# How many significantly up or down regulated genes are there at a threshold of 0.05?
sig <- getSig(cuff, alpha=0.05, level='genes')
length(sig)
# We have 0!

# Get gene data from cuff database:
# sigGenes <- getGenes(cuff,sig)

# Examine the gene set:
# sigGenes

# Draw scatter plot with this subset of genes:
# csScatter(sigGenes, 'G1', 'G2')

# Draw a heatmap of these genes:
# csHeatmap(sigGenes, cluster='both')
