## To install and load:
source("http://bioconductor.org/biocLite.R")
biocLite("DESeq2")

library(DESeq2)
#setwd("YOUR/CHOICE")


## Importation and file exploration.-----------
countdata <- read.table("final_test.txt", header=TRUE, row.names=1)


# Convert to a matrix:
countdata <- as.matrix(countdata)
head(countdata)

# Assign conditions - "F": Frozen, "R": RNAlaterfirst.
(condition <- factor(c(rep("F", 16), rep("R", 16))))


## Data.frame creation and instantiation.-----------

# Create columnar data.frame:
(coldata <- data.frame(row.names=colnames(countdata), condition))

# Instantiate the DESeqDataSet:
dds <- DESeqDataSetFromMatrix(countData=countdata, colData=coldata, design=~condition)
dds


## DESeq Pipeline.-----------
# DESeq pipeline, WARNING: this takes a while:
dds <- DESeq(dds)

# Let's look at the results from the pipeline:
res <- results(dds)
res <- res [order(res$padj),]
head(res)


## Visualize the results.-----------
# Plot the dispersions (placed in PWD):
png("qc-dispersions.png", 1000, 1000, pointsize=20)
plotDispEsts(dds, main="Dispersion plot")
dev.off()


#MA-plots are used to study dependences between the log ratio of two variables 
#and the mean values of the same two variables. 
#The log ratios of the two measurements are called M values (from “minus” in the log scale) 
#and are represented in the vertical axis. The mean values of the two measurements are 
#called A values (from “average” in the log scale) and are represented in the horizontal axis.
#Lower count reads are on the left.
plotMA(dds,ylim=c(-2,2),main="DESeq2")
png("deseq2_MAplot.png")

# We can save the table, and also print out some information on what the columns mean.
mcols(res, use.names=TRUE)


## Clustering.-----------
# Now we want to transform the raw discretely distributed counts so that we can do clustering.
# Regularized log transformation for use in clustering/heatmaps and more:
# Here we choose blind so that the initial conditions setting does not influence the outcome, 
# ie we want to see if the conditions cluster based purely on the individual datasets, 
# in an unbiased way.
# WARNING, may take a long time:
rld <- rlogTransformation(dds, blind = TRUE)
# Non-blind:
# rld <- rlogTransformation(dds)

# Take a peak at the rld data:
head(assay(rld))        #What does the assay command do?

# Make a histogram, in PWD?:
hist(assay(rld))

# Colors for plots below
## Ugly:
## (mycols <- 1:length(unique(condition)))
## Use RColorBrewer, better
library(RColorBrewer)
(mycols <- brewer.pal(8, "Dark2")[1:length(unique(condition))])

# Sample distance heatmap
sampleDists <- as.matrix(dist(t(assay(rld))))
library(gplots)



#In PWD?:
png("qc-heatmap-samples.png", w=1000, h=1000, pointsize=20)



heatmap.2(as.matrix(sampleDists), key=F, trace="none",
          col=colorpanel(100, "black", "white"),
          ColSideColors=mycols[condition], RowSideColors=mycols[condition],
          margin=c(10, 10), main="Sample Distance Matrix")
dev.off()


## Principal components analysis.-----------
# Do with built-in DESeq2 function:
DESeq2::plotPCA(rld, intgroup="condition")

# rld_pca <- function (rld, intgroup = "condition", ntop = 500, colors=NULL, legendpos="bottomleft", main="PCA Biplot", textcx=1, ...) {
#         require(genefilter)
#         require(calibrate)
#         require(RColorBrewer)
#         rv = rowVars(assay(rld))
#         select = order(rv, decreasing = TRUE)[seq_len(min(ntop, length(rv)))]
#         pca = prcomp(t(assay(rld)[select, ]))
#         fac = factor(apply(as.data.frame(colData(rld)[, intgroup, drop = FALSE]), 1, paste, collapse = " : "))
#         if (is.null(colors)) {
#                 if (nlevels(fac) >= 3) {
#                         colors = brewer.pal(nlevels(fac), "Paired")
#                 }   else {
#                         colors = c("black", "red")
#                 }
#         }
#         pc1var <- round(summary(pca)$importance[2,1]*100, digits=1)
#         pc2var <- round(summary(pca)$importance[2,2]*100, digits=1)
#         pc1lab <- paste0("PC1 (",as.character(pc1var),"%)")
#         pc2lab <- paste0("PC1 (",as.character(pc2var),"%)")
#         plot(PC2~PC1, data=as.data.frame(pca$x), bg=colors[fac], pch=21, xlab=pc1lab, ylab=pc2lab, main=main, ...)
#         with(as.data.frame(pca$x), textxy(PC1, PC2, labs=rownames(as.data.frame(pca$x)), cex=textcx))
#         legend(legendpos, legend=levels(fac), col=colors, pch=20)
#              rldyplot(PC2 ~ PC1, groups = fac, data = as.data.frame(pca$rld),
#                     pch = 16, cerld = 2, aspect = "iso", col = colours, main = draw.key(key = list(rect = list(col = colours),
#                                                                                                  terldt = list(levels(fac)), rep = FALSE)))
# }

png("qc-pca.png", 1000, 1000, pointsize=20)
rld_pca(rld, colors=mycols, intgroup="condition", xlim=c(-75, 35))
dev.off()


## Differential expression results.-----------
res <- results(dds)
table(res$padj<0.05)

# Order by adjusted p-value
res <- res[order(res$padj), ]

# Merge with normalized count data
resdata <- merge(as.data.frame(res), as.data.frame(counts(dds, normalized=TRUE)), by="row.names", sort=FALSE)
#names(resdata)[1] <- "Gene"
head(resdata)

# Write results to comma-separated file in PWD:
write.csv(resdata, file="diffexpr-results.csv")


# Create and examine a plot of the p-values:
hist(res$pvalue, breaks=50, col="grey")

# Let's look at the independent filtering:
attr(res, "filterThreshold")
plot(attr(res,"filterNumRej"), type="b", xlab="quantiles of baseMean", ylab="number of rejections")


# MA plot.-----------
# Do with built-in DESeq2 function:
DESeq2::plotMA(dds, ylim=c(-1,1))

# Would like to use this one but cex=1 throws an error.
# DESeq2::plotMA(dds, ylim=c(-1,1), cex=1)

# Alternative:
# maplot <- function (res, thresh=0.05, labelsig=TRUE, textcx=1, ...) {
#         with(res, plot(baseMean, log2FoldChange, pch=20, cex=.5, log="x", ...))
#         with(subset(res, padj<thresh), points(baseMean, log2FoldChange, col="red", pch=20, cex=1.5))
#         if (labelsig) {
#                 require(calibrate)
#                 with(subset(res, padj<thresh), textxy(baseMean, log2FoldChange, labs=Gene, cex=textcx, col=2))
#         }
# }
png("diffexpr-maplot.png", 1500, 1000, pointsize=20)

head(resdata)

# TODO: NEED TO REMOVE HEADER.
resdata_1 <- resdata[3, ]
head(resdata_1)
maPlot(resdata, main="MA Plot")
dev.off()

names(resdata)[1] <- "Gene"
# Volcano plot with "significant" genes labeled
volcanoplot <- function (res, lfcthresh=2, sigthresh=0.05, main="Volcano Plot", legendpos="bottomright", labelsig=TRUE, textcx=1, ...) {
        with(res, plot(log2FoldChange, -log10(pvalue), pch=20, main=main, ...))
        with(subset(res, padj<sigthresh ), points(log2FoldChange, -log10(pvalue), pch=20, col="red", ...))
        with(subset(res, abs(log2FoldChange)>lfcthresh), points(log2FoldChange, -log10(pvalue), pch=20, col="orange", ...))
        with(subset(res, padj<sigthresh & abs(log2FoldChange)>lfcthresh), points(log2FoldChange, -log10(pvalue), pch=20, col="green", ...))
        if (labelsig) {
                require(calibrate)
                with(subset(res, padj<sigthresh & abs(log2FoldChange)>lfcthresh), textxy(log2FoldChange, -log10(pvalue), labs=Gene, cex=textcx, ...))
        }
        legend(legendpos, xjust=1, yjust=1, legend=c(paste("FDR<",sigthresh,sep=""), paste("|LogFC|>",lfcthresh,sep=""), "both"), pch=20, col=c("red","orange","green"))
}
png("diffexpr-volcanoplot.png", 1200, 1000, pointsize=20)
volcanoplot(resdata, lfcthresh=1, sigthresh=0.05, textcx=.8, xlim=c(-2.3, 2))
dev.off()
