#!/usr/bin/env bash
#$ -S /bin/bash
#$ -cwd
#$ -M jk3235@drexel.edu
#$ -P nsftuesPrj
#$ -q all.q@@intelhosts
#$ -l h_rt=12:00:00
. /etc/profile.d/modules.sh
module load shared
module load proteus
module load sge/univa

module load gcc/4.8.1
module load qiime/gcc/64/1.8.0

path=/home/jk3235/tutorial
refc=/mnt/HA/groups/nsftuesGrp/data/gg_13_8_otus

time -p pick_otus.py -i ${path}/All_16S.fasta -m uclust_ref -r ${refc}/rep_set/97_otus.fasta -o ${TMP}/ucr_otus/
pick_rep_set.py -i ${TMP}/ucr_otus/All_16S_otus.txt -f ${path}/All_16S.fasta -o ${TMP}/ucr_rep_set1.fasta

time -p align_seqs.py -i ${TMP}/ucr_rep_set1.fasta -t ${path}/core_set_aligned.fasta.imputed -o ${TMP}/ucr_p_aligned/
make_phylogeny.py -i ${TMP}/ucr_p_aligned/ucr_rep_set1_aligned.fasta -o ${TMP}/ucr_p_rep_phylo.tre

time -p align_seqs.py -i ${TMP}/ucr_rep_set1.fasta -m muscle  -o ${TMP}/ucr_m_aligned/
make_phylogeny.py -i ${TMP}/ucr_m_aligned/ucr_rep_set1_aligned.fasta -o ${TMP}/ucr_m_rep_phylo.tre

time -p align_seqs.py -i ${TMP}/ucr_rep_set1.fasta -m infernal -t seed.16s.reference_model.sto -o ${TMP}/ucr_i_aligned/
make_phylogeny.py -i ${TMP}/ucr_i_aligned/ucr_rep_set1_aligned.fasta -o ${TMP}/ucr_i_rep_phylo.tre

cp -r ${TMP}/ ${path}
rm -rf ${TMP}