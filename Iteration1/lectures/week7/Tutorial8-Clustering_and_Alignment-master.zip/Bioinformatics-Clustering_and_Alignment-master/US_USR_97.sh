#!/usr/bin/env bash
#$ -S /bin/bash
#$ -cwd
#$ -M jk3235@drexel.edu
#$ -P nsftuesPrj
#$ -q all.q@@intelhosts
#$ -l h_rt=24:00:00
. /etc/profile.d/modules.sh
module load shared
module load proteus
module load sge/univa

module load gcc/4.8.1
module load qiime/gcc/64/1.8.0

path=/home/jk3235/tutorial
refc=/mnt/HA/groups/nsftuesGrp/data/gg_13_8_otus

#################usearch########################

time -p pick_otus.py -i ${path}/All_16S.fasta -m usearch --suppress_reference_chimera_detection -o ${TMP}/us_otus/
pick_rep_set.py -i ${TMP}/us_otus/All_16S_otus.txt -f ${path}/All_16S.fasta -o ${TMP}/us_rep_set1.fasta

time -p align_seqs.py -i ${TMP}/us_rep_set1.fasta -t ${path}/core_set_aligned.fasta.imputed -o ${TMP}/us_p_aligned/
make_phylogeny.py -i ${TMP}/us_p_aligned/us_rep_set1_aligned.fasta -o ${TMP}/us_p_rep_phylo.tre

time -p align_seqs.py -i ${TMP}/us_rep_set1.fasta -m muscle  -o ${TMP}/us_m_aligned/
make_phylogeny.py -i ${TMP}/us_m_aligned/us_rep_set1_aligned.fasta -o ${TMP}/us_m_rep_phylo.tre

time -p align_seqs.py -i ${TMP}/us_rep_set1.fasta -m infernal -t seed.16s.reference_model.sto -o ${TMP}/us_i_aligned/
make_phylogeny.py -i ${TMP}/us_i_aligned/us_rep_set1_aligned.fasta -o ${TMP}/us_i_rep_phylo.tre

#################usearch_ref####################

time -p pick_otus.py -i ${path}/All_16S.fasta -m usearch_ref -r ${refc}/rep_set/97_otus.fasta  --suppress_reference_chimera_detection -o ${TMP}/usr_otus/
pick_rep_set.py -i ${TMP}/usr_otus/All_16S_otus.txt -f ${path}/All_16S.fasta -o ${TMP}/usr_rep_set1.fasta

time -p align_seqs.py -i ${TMP}/usr_rep_set1.fasta -t ${path}/core_set_aligned.fasta.imputed -o ${TMP}/usr_p_aligned/
make_phylogeny.py -i ${TMP}/usr_p_aligned/usr_rep_set1_aligned.fasta -o ${TMP}/usr_p_rep_phylo.tre

time -p align_seqs.py -i ${TMP}/usr_rep_set1.fasta -m muscle  -o ${TMP}/usr_m_aligned/
make_phylogeny.py -i ${TMP}/usr_m_aligned/usr_rep_set1_aligned.fasta -o ${TMP}/usr_m_rep_phylo.tre

time -p align_seqs.py -i ${TMP}/usr_rep_set1.fasta -m infernal -t seed.16s.reference_model.sto -o ${TMP}/usr_i_aligned/
make_phylogeny.py -i ${TMP}/usr_i_aligned/usr_rep_set1_aligned.fasta -o ${TMP}/usr_i_rep_phylo.tre

cp -r ${TMP}/ ${path}
rm -rf ${TMP}