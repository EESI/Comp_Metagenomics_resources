# Bioinformatics-Clustering and Alignment
CD: CDHIT

UC: UCLUST

UCR: UCLUST Reference

US: USEARCH

USR: USEARCH Reference

P: PyNAST

M: MUSCLE

I: INFERNAL

Each submitter is composed of the following stages.
* Clustering
* Pick Representative OTU
* Aligning
* Making Phylogeny Tree File
