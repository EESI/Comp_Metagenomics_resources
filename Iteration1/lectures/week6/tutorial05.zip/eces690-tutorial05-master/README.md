# ECES690 Tutorial 5: De novo assembly

Please see [the assembly tutorial](assembly-tutorial.md).
