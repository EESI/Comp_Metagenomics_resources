# ECES490_Metagenomics
A metagenomic analysis of sequenced microbiomes in healthy mice vs. DEN toxin injected, FLD induced mice on control and high fat diets.  The analysis was mostly conducted on Drexel's Proteus cluster, and scripts depend on file locations.  Some analysis was done using third party applications and those results are presented in the report.
