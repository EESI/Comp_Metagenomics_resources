from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import generic_dna


#my_dna=Seq(seq,generic_dna)
#my_dna_complement=my_dna.complement()

handle = open("CSJP002A_R2.fastq","rU")
outfile = open("CSJP002A_R2_comp.fastq","w")	
for line in handle:
	id = line
	seq = Seq(handle.next(),generic_dna)
	comp = seq.complement()
	spacer = handle.next()
	quality = handle.next()
	
	seqStr = str(seq)
	compStr = str(comp)
	
	outfile.write(id)
	#outfile.write(seqStr)
	outfile.write(compStr)
	outfile.write(spacer)
	outfile.write(quality)

handle.close()

handle = open("CSJP002B_R2.fastq","rU")
outfile = open("CSJP002B_R2_comp.fastq","w")	
for line in handle:
	id = line
	seq = Seq(handle.next(),generic_dna)
	comp = seq.complement()
	spacer = handle.next()
	quality = handle.next()
	
	seqStr = str(seq)
	compStr = str(comp)
	
	outfile.write(id)
	#outfile.write(seqStr)
	outfile.write(compStr)
	outfile.write(spacer)
	outfile.write(quality)

handle.close()

handle = open("CSJP002C_R2.fastq","rU")
outfile = open("CSJP002C_R2_comp.fastq","w")	
for line in handle:
	id = line
	seq = Seq(handle.next(),generic_dna)
	comp = seq.complement()
	spacer = handle.next()
	quality = handle.next()
	
	seqStr = str(seq)
	compStr = str(comp)
	
	outfile.write(id)
	#outfile.write(seqStr)
	outfile.write(compStr)
	outfile.write(spacer)
	outfile.write(quality)

handle.close()