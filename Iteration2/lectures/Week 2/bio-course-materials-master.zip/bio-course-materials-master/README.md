bio-course-materials
====================

Course materials for a bioinformatics course. 
