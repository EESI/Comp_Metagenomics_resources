#!/usr/bin/env bash 

# this is a basic bash script
f_name=$1 # get the first argument 
l_name=$2 # get the second argument 
echo "Hello $f_name $l_name"
