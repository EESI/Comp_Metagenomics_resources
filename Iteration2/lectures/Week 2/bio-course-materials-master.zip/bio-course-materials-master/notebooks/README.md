
# Links to Notebooks 

* [Bash Tutorial](http://nbviewer.ipython.org/github/gditzler/bio-course-materials/blob/master/notebooks/Bash-Tutorial.ipynb)
* [BioPython Tutorial](http://nbviewer.ipython.org/github/gditzler/bio-course-materials/blob/master/notebooks/BioPython-Tutorial.ipynb)
