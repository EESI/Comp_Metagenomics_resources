## Bioinformatics Class

Class materials with an emphasis on R programming. It is expected that you have little to no experience with programming or bioinformatics, but these notes are not intended to be a rigorious introduction to core programming principles. 

Associated data and functions can be found here: https://gist.github.com/sw1/8870a124624f31585d5c15be72fcfc21
