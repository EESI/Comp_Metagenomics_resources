# File Information 

* `david-complete.biom`: 
* `david-stool-b.txt`: 
* `david14_otus_metadata_saliva_A.txt`: 
* `otu.table.ggref`: 
* `david-saliva-a.txt`: 
* `david.biom`: 
* `david14_otus_metadata_stool_A.txt`: 
* `otu_table-metadata.txt`: 
* `david-stool-a.txt`: 
* `david.txt`: 
* `david14_otus_metadata_stool_B.txt`: 


