# Mutation-Signature-Project
Analysis Of TCGA mutation signatures using R packages

For project details and methods see the Project Presentation and Project Report files

The main pipeline was coded using R packages and the full script in file titled Project script.R
Some of the code for the pipeline relies on MATLAB; these are named Clustering.m, Project.m and MaxSig.m
In the main R script it has been commented at which parts the files are expoted to or imported from MATLAB

Figures generated for background Analysis are in the project presentation and figures generated for analysis 
of clustered subsets dendograms of clustered groups tited with the cancer name and in .jpg format. Figures for pathway analysis are in
the subsetpathway figures file, Subset signature figures file and subset mutation load figures file
