
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 22 10:48:57 2019

@author: taha
"""

import numpy as np
import pandas as pd
from Bio import SeqIO
import datetime
import os
from xlrd import open_workbook
from itertools import product
from tempfile import mkdtemp
import os.path as path

K = 8

print('KMC3 KMER COUNT, K = '+str(K))

MetaFileName = 'StaphylococcusAureus.xlsx'
META = pd.read_excel('/home/taha/Desktop/AMR/'+MetaFileName)
wb = open_workbook('/home/taha/Desktop/AMR/'+MetaFileName)
for sheet in wb.sheets():
    t=6
    
print('Metadata file loaded')

os.chdir('/home/taha/Desktop/AMR')

NumMissingFiles = 0
MissingFilesList = []

NumberOfGenomesWithMIC = np.sum(META.iloc[:,9] == 'MIC')

BadCommand = []

KEYS = [''.join(c) for c in product('ACGT', repeat=K)]

ColNum = {}
for ii in range(len(KEYS)):
    ColNum[KEYS[ii]] = ii

print('Creating empty array... ',end='')
COL = ['Antibiotic','MIC']
TABLEmeta = pd.DataFrame(np.zeros([NumberOfGenomesWithMIC,len(COL)]), columns=COL)
filename = path.join(mkdtemp(), '/home/taha/Desktop/AMR/DISKTABLE.dat')
TABLE = np.memmap(filename, dtype='float32', mode='w+',\
                  shape=(NumberOfGenomesWithMIC,4**K))
print('Done')

T1=datetime.datetime.now()
RowN = -1
for counter in range(META.shape[0]):

    
    if META.iloc[counter,9] == 'MIC':
        
        # Check fo NaN
        if str(META.iloc[counter,7]) == 'nan':
            continue
        
        print(str(datetime.datetime.today().replace(microsecond=0))+\
              ' ['+str(counter)+'/'+str(META.shape[0])+'] ',end='')
        print('ADDING NEW MIC DATA: '+str(META.iloc[counter,2])+'. MIC: '+\
              str(META.iloc[counter,7]))
        
        READID = sheet.cell(1+counter,1).value
        Antibiotic = META.iloc[counter,3]
        MIC = META.iloc[counter,7]
        
        FileAdd = '/home/taha/Desktop/AMR/FASTA/'+str(READID)+'.fna'
        
        try:
            fasta_sequences = SeqIO.parse(open(FileAdd),'fasta')    
        except:
            NumMissingFiles = NumMissingFiles + 1
            MissingFilesList.append(str(READID))
            print('Warning: '+str(READID)+'.fna does not exist.')
            continue
        
        # Increase the row number
        RowN = RowN + 1
        
        TABLEmeta.loc[RowN,'Antibiotic'] = Antibiotic
        TABLEmeta.loc[RowN,'MIC'] = MIC
        
        COMMAND1 = "kmc -k"+str(K)+" -cs10000000000 -ci0 -fm  "+\
        "/home/taha/Desktop/AMR/FASTA/"+str(READID)+".fna kmer2 tmp "
        COMMAND2 = "kmc_tools transform kmer2 dump out"
        
        ErrorNumber1 = os.system(COMMAND1+'>/dev/null 2>&1')
        ErrorNumber2 = os.system(COMMAND2+'>/dev/null 2>&1')
        
        if ErrorNumber1 or ErrorNumber2:
            BadCommand.append(COMMAND1)
            print("Error in KMC")
            continue
        
        KMCres = pd.read_csv('out',header=-1,sep='\t')
        for kk in range(len(KMCres)):
#            print(kk)
            TABLE[RowN,ColNum[KMCres.iloc[kk,0]]] = KMCres.iloc[kk,1]

        fasta_sequences.close()

T2=datetime.datetime.now()

# Add column names
TABLEdf = pd.DataFrame(TABLE , columns=KEYS)

# Attach meta data
FINALTABLE = pd.concat([TABLEmeta, TABLEdf], axis=1, sort=False)

OutpuFile = '/home/taha/Desktop/AMR/TRAININGDATA.'+MetaFileName+' K'\
             +str(K)+'-'+str(datetime.datetime.today().replace(microsecond=0))\
             +'.tsv'

print('Saving data to file '+OutpuFile,end='... ')
FINALTABLE.to_csv(OutpuFile,sep='\t')
print('Done!')
print('All done!')
print('K: '+str(K))
print('Counted genomes: '+str(NumberOfGenomesWithMIC))
print('Kmer count time: '+str(T2-T1))
print('Total command errors: '+str(len(BadCommand)))