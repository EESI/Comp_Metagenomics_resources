from xlrd import open_workbook
import os
import ftplib

wb = open_workbook('/home/taha/Desktop/AMR/meta_pa2.xlsx')
for sheet in wb.sheets():
    number_of_rows = sheet.nrows
    number_of_columns = sheet.ncols

    genid = []
    for row in range(1, number_of_rows):
        if (sheet.cell(row,9).value) == 'MIC':
            value  = (sheet.cell(row,1).value)
            if value not in genid:
#                print(row/number_of_rows)
                genid.append(value)
print(len(genid))


address = "ftp.patricbrc.org"
with ftplib.FTP(address) as ftp:
    ftp.login()
    ftp.cwd("genomes")
    for gid in genid:
        f = gid + ".fna"
        ftp.cwd(gid)
        ftp.retrbinary('RETR ' + f, open(f, 'wb').write)
        ftp.cwd('../')
    ftp.quit()

