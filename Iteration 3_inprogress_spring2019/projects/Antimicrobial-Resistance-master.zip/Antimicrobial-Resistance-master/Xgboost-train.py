#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat May 18 21:01:17 2019

@author: appleuser

python Xgboost-train.py 
"""
import pandas as pd
import numpy as np
import scipy.stats
import xgboost as xgb
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.model_selection import StratifiedKFold
import os


cwd = os.getcwd()

def accuracy_dilute(prdc,target):
    total = len(prdc);
    n = 0
    for i,j in zip(prdc,target):
        if j/2 < i and i < 2*j:
            n += 1
    return n/total

#Change your file name here to read the data
df = pd.read_excel(cwd + "/filename",'\t');
#df = pd.read_csv("/Users/appleuser/Downloads/MIC predict/TRAININGDATA.K5-2019-05-22 18_18_09.080251.tsv",sep = "\t");

#depend on the data, in the MIC column, it might have '-' in some data point so you can remove it with this code
df = df[df['MIC'].map(lambda x: False if '-' in x else True)];

def process(df):
    df['Antibiotic_new'] = df['Antibiotic'].str.split('/').str[0]
    df['MIC_new'] = df['MIC'].str.split('/').str[0]
    df = df.drop(['MIC','Antibiotic'], axis=1)
    return df

df = process(df)

#remove all the low frequecy antibiotics
freq = df['Antibiotic_new'].value_counts()

#The threshold that can get rid of the low frequency antibiotic
threshold = 10
to_remove = freq[freq < threshold].index
df['Antibiotic_new'].replace(to_remove, np.nan, inplace=True)
df = df[pd.notnull(df['Antibiotic_new'])]

#df = df[~df.MIC.str.contains("-")];
#df = df[~df.MIC.str.contains("/")];
(_,tar_col) = df.shape;
tar_col = tar_col-1

X = df.iloc[:,1:tar_col].values;
Y = df.iloc[:,tar_col].values;
Y = Y.astype(np.float);

labelencoder_X = LabelEncoder();
X[:,tar_col-2] = labelencoder_X.fit_transform(X[:,tar_col-2])

Antibiotic_idx = X[:,tar_col-2];
Antibiotic_idx = list(Antibiotic_idx)
Antibiotic_idx = np.array(Antibiotic_idx)

#One-hot encoode
onehotencoder = OneHotEncoder(categorical_features=[tar_col-2]);
X = onehotencoder.fit_transform(X).toarray()
X = X.astype(np.int);

## Splitting training and testing dataset
#X_train, X_test, Y_train, Y_test = train_test_split(X,Y, test_size = 0.2, random_state = 123);


##Stratified croess-validation

X_train_g = [];
Y_train_g = [];
model_list = [];
acc_list = [];

#set up stratified k-fold
kfold = 9
skf = StratifiedKFold(n_splits=kfold);

#from itertools import groupby
#[len(list(group)) for key, group in groupby(Antibiotic_idx]

### set up model
#model = XGBRegressor(learning_rate=0.01,
                 #n_estimators = 100,
                 #max_depth=6,
                 #seed=123);

#seperate the test data from the overall dataset
X_train, X_test, Y_train, Y_test,An_train,An_test= train_test_split(X,Y,Antibiotic_idx,test_size = 0.1, random_state = 1,stratify = Antibiotic_idx);
                     

params = {
    'eta': 0.1,
    'objective':'reg:linear',
    'seed': 99,
    'nthread': 4,
    'max_depth': 29
    }

n_estimators = 100

for i, (train_index, test_index) in enumerate(skf.split(X_train, An_train)):
    print('[Fold %d/%d]' % (i + 1, kfold));
    X_train_v, X_validate = X_train[train_index], X_train[test_index];
    Y_train_v, Y_validate = Y_train[train_index], Y_train[test_index];
    
    d_train = xgb.DMatrix(X_train_v,Y_train_v);
    d_validate = xgb.DMatrix(X_validate,Y_validate);
    d_test = xgb.DMatrix(X_test);
    
    watchlist = [(d_train, 'train'), (d_validate, 'valid')];
    
    model = xgb.train(params,d_train,num_boost_round = n_estimators,evals = watchlist);
    Y_predict = model.predict(d_test, ntree_limit=model.best_ntree_limit);
    
    acc = accuracy_dilute(Y_predict,Y_test);
    print(acc);
    acc_list.append(acc);
    model_list.append(model);

print(acc_list)


#calculate the mean accuracy of all the models with 95% confidence interval
def mean_confidence_interval(data, confidence=0.95):
    a = 1.0 * np.array(data)
    n = len(a)
    m, se = np.mean(a), scipy.stats.sem(a)
    h = se * scipy.stats.t.ppf((1 + confidence) / 2., n-1)
    return m, m-h, m+h

#a  = [0.5352112676056338, 0.5633802816901409, 0.5549295774647888, 0.5746478873239437, 0.5690140845070423, 0.5464788732394367, 0.5915492957746479, 0.5549295774647888, 0.5211267605633803]                     
acc = mean_confidence_interval(acc_list)

###############################################################################
#grid search (max_depth, min_child_weight)
###############################################################################
#This is the customized accuracy function which can fit into the model train using argument 'feval'
def accuracy(prdc,target):
    total = len(prdc);
    n = 0
    for i,j in zip(prdc,target.get_label()):
        if j/2 < i and i < 2*j:
            n += 1
    return 'acc', n/total

params = {
    # Parameters that we are going to tune.
    'max_depth':6,
    'min_child_weight': 1,
    'eta':.1,
    'subsample': 1,
    'colsample_bytree': 1,
    # Other parameters
    'objective':'reg:linear',
}


#You can change the paramemters and and their range here (max_depth, min_child_weight, colsample_bytree, subsample)
gridsearch_params = [
    (max_depth, min_child_weight)
    for max_depth in range(2,8)
    for min_child_weight in range(1,4)]

d_train = xgb.DMatrix(X_train,Y_train);
num_boost_round = 999

max_acc = 0
best_params = None
for max_depth, min_child_weight in gridsearch_params:
    print("CV with max_depth={}, min_child_weight={}".format(
                             max_depth,
                             min_child_weight))
    # Update our parameters
    params['max_depth'] = max_depth
    params['min_child_weight'] = min_child_weight
    # Run CV
    cv_results = xgb.cv(
        params,
        d_train,
        num_boost_round=num_boost_round,
        seed=42,
        nfold=5,
        early_stopping_rounds=10,
        #here is the cutomized function
        feval = accuracy
    )
    # Update best ACC
    mean_acc = cv_results['test-acc-mean'].max()
    boost_rounds = cv_results['test-acc-mean'].argmax()
    print("\tMAE {} for {} rounds".format(mean_acc, boost_rounds))
    if mean_acc > max_acc:
        max_acc = mean_acc
        best_params = (max_depth,min_child_weight)
        
#print out the best result we can get
print('Average accuracy without tuning parameter')
print(acc)
print("Best params: max_depth {}, min_child_weight {}, ACC: {}".format(best_params[0], best_params[1], max_acc))











