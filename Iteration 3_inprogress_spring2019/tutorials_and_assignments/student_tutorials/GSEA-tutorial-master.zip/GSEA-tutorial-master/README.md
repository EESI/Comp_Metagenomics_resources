# GSEA Tutorial

GSEA-background and Overview of GSEA JAVA app is in .ppt file

Files used with the GSEA java app demo for the tutorial are in the example files .zip file

Code for the R version fgsea is in fgsea.txt file
