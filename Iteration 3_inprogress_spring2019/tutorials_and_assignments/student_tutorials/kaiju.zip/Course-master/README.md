# Course
This is the slides and paper of Kaiju classification.

All the result links are in the slides.

You can parse the .out file using BBEdit.
